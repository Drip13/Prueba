<?php $__env->startSection('template_title'); ?>
    <?php echo e($empresa->name ?? 'Show Empresa'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div class="float-left">
                                <span class="card-title">Detalles de la Empresa</span>
                            </div>
                            <div class="float-right">
                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('empresas.index')); ?>"> Atrás</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre de la empresa:</strong>
                            <?php echo e($empresa->nombrempresa); ?>

                        </div>
                        <div class="form-group">
                            <strong>Dirección:</strong>
                            <?php echo e($empresa->direccion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Correo Electrónico:</strong>
                            <?php echo e($empresa->emailempresa); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telempresa:</strong>
                            <?php echo e($empresa->telempresa); ?>

                        </div>
                        <div class="form-group">
                            <strong>Logo:</strong>
                            <img src="<?php echo e(asset('uploads').'/'.$empresa->logo); ?>" width="300" >
                        </div>
                        <div class="form-group">
                            <br>
                            <strong>Sitio Web:</strong>
                            <?php echo e($empresa->web); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PruebaTec2\resources\views/empresa/show.blade.php ENDPATH**/ ?>