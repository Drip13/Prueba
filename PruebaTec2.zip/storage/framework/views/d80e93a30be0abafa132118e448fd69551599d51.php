<?php $__env->startSection('template_title'); ?>
    <?php echo e($empresa->name ?? 'Show Empresa'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div class="float-left">
                                <span class="card-title"><?php echo app('translator')->get('messages.companyshow'); ?></span>
                            </div>
                            <div class="float-right">
                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('empresas.index')); ?>"><?php echo app('translator')->get('messages.back'); ?></a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong><?php echo app('translator')->get('messages.compname'); ?>:</strong>
                            <?php echo e($empresa->nombrempresa); ?>

                        </div>
                        <div class="form-group">
                            <strong><?php echo app('translator')->get('messages.compadress'); ?>:</strong>
                            <?php echo e($empresa->direccion); ?>

                        </div>
                        <div class="form-group">
                            <strong><?php echo app('translator')->get('messages.compemail'); ?>:</strong>
                            <?php echo e($empresa->emailempresa); ?>

                        </div>
                        <div class="form-group">
                            <strong><?php echo app('translator')->get('messages.comptel'); ?>:</strong>
                            <?php echo e($empresa->telempresa); ?>

                        </div>
                        <div class="form-group">
                            <strong><?php echo app('translator')->get('messages.complogo'); ?>:</strong>
                            <img src="<?php echo e(asset('uploads').'/'.$empresa->logo); ?>" width="300" >
                        </div>
                        <div class="form-group">
                            <br>
                            <strong><?php echo app('translator')->get('messages.compweb'); ?>:</strong>
                            <?php echo e($empresa->web); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PruebaTec2\resources\views/empresa/show.blade.php ENDPATH**/ ?>