<?php $__env->startSection('template_title'); ?>
    <?php echo e($empleado->name ?? 'Show Empleado'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div class="float-left">
                                <span class="card-title">Detalles del empleado</span>
                            </div>
                            <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-danger btn-sm"  data-placement="left"><?php echo e(__('Atrás')); ?></a>
                        </div>
                    </div>
                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombres:</strong>
                            <?php echo e($empleado->nombre1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Primer Apellido:</strong>
                            <?php echo e($empleado->apellido1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Segundo Apellido:</strong>
                            <?php echo e($empleado->apellido2); ?>

                        </div>
                        <div class="form-group">
                            <strong>Correo:</strong>
                            <?php echo e($empleado->emailempleado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($empleado->telempleado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Empresa:</strong>
                            <?php echo e($empleado->empresa_id); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PruebaTec2\resources\views/empleado/show.blade.php ENDPATH**/ ?>